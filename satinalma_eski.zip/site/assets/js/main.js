$(document).ready(function () {
  $('a[href="#"]').click(function (e) { e.preventDefault ? e.preventDefault() : e.returnValue = false; });

  var date = new Date().toJSON().slice(0, 10).replace(/-/g, '-');
  var time = new Date().toString().slice(16, 21);

  $('#currentDate').append(date);
  $('#currentTime').append(time);

  $('.addNewGroup').click(function () {
    $('.addGroupWrap ul').removeClass('openGroupList')
    $(this).next('.addGroupWrap ul').toggleClass('openGroupList')
  });

  $('.addNewGroupCloseBtn').click(function () {
    $('.addGroupWrap ul').removeClass('openGroupList')
  });

  $('.hddMbtn').click(function () {
    $('.hddMList').toggleClass('smOpen')
  });

  $('.projectInfoBtn').click(function () {
    $('.projectInfoModal').css({ display: 'flex' })
  })
  $('.projectInfoCloseModal').click(function () {
    $('.projectInfoModal').hide()
  });

  $('.ccNotesBtn').click(function () {
    $('.ccNotesModal').css({ display: 'flex' })
  })
  $('.ccNotesCloseModal').click(function () {
    $('.ccNotesModal').hide()
  });

  $('.ccDocumentsBtn').click(function () {
    $('.ccDocumentsModal').css({ display: 'flex' })
  })
  $('.ccDocumentsCloseModal').click(function () {
    $('.ccDocumentsModal').hide()
  });

  $('.confirmBidBtn').click(function () {
    $('.confirmBidModal').css({ display: 'flex' })
  })
  $('.confirmBidCloseModal').click(function () {
    $('.confirmBidModal').hide()
  });

  $('.allBidsModalBtn').click(function () {
    $('.allBidsModal').css({ display: 'flex' })
  })
  $('.allBidsCloseModal').click(function () {
    $('.allBidsModal').hide()
  });

  $('.hddMbtn').click(function () {
    $('.navIcon').toggleClass('open')
  });

  $('.mobileMenuBtn').click(function () {
    $('.navIcon').toggleClass('open')
    $('.mobileMenuWrap').toggle();
  });

  $(window).on('resize', function(){
    if( $(window).width() > 768 ) {
      $('.mobileMenuWrap').hide();
      $('.navIcon').removeClass('open')
    }
  });

  $('.sideBarToggle').click(function () {
    $('.sideMenu').toggleClass('smallMenu')
    $('.rightPanel').toggleClass('bigRightPanel')
  });

  $('.nCloseBtn').click(function () {
    $('.notificationWrap').hide()
  });

  $('.toggleBtn').click(function () {
    $(this).toggleClass('open');
  });

  $('.allBidsToggle').click(function () {
    $('.allBids ul').toggle();
    $('.allBids .rpCardSubHead').toggleClass('margin');
  });
  
  $('.tcoBtn').click(function () {
    $('.tcoModal').css({ display: 'flex' })
  })
  $('.tcoBtnCloseModal').click(function () {
    $('.tcoModal').hide()
  });

  $('.dmOpenBtn').click(function () {
    $('.deleteModal').hide();
    $(this).next('.deleteModal').show()
  });
  $('.dmCloseBtn, .dmCancel').click(function () {
    $('.deleteModal').hide();
  });

  $("#backToTop").click(function () {
    $("html, body").animate({ scrollTop: 0 }, 1000);
  });
  function backToTopShow() {
    if ($(window).scrollTop() > 50) {
      $("#backToTop").show();
    } else {
      $("#backToTop").hide();
    }
  }
  backToTopShow();
  $(window).scroll(function () {
    backToTopShow();
  });

  //ihale oluşturma ekranında, ihale tipi seçimi (english-dutch. checkbox)
  $('input[name="bidTypeChange"]').click(function () {
    if ($(this).attr('value') == 'bidTypeEnglish') {
      $('.btEnglish').addClass('open')
      $('.btDutch').removeClass('open')
    }
    if ($(this).attr('value') == 'bidTypeDutch') {
      $('.btDutch').addClass('open')
      $('.btEnglish').removeClass('open')
    }
  })
})

/* Counter Start */
var countDownDate = new Date('Jan 5, 2021 1:33:25').getTime()
var x = setInterval(function () {
  var now = new Date().getTime()
  var distance = countDownDate - now

  // var days = Math.floor(distance / (1000 * 60 * 60 * 24)); - days -

  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  if (hours <= 9) {
    var hoursMod = '0' + hours
  } else {
    var hoursMod = hours
  }

  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
  if (minutes <= 9) {
    var minutesMod = '0' + minutes
  } else {
    var minutesMod = minutes
  }

  var seconds = Math.floor((distance % (1000 * 60)) / 1000)
  if (seconds <= 9) {
    var secondsMod = '0' + seconds
  } else {
    var secondsMod = seconds
  }

  if (document.getElementById('counter')) {
    document.getElementById('counter').innerHTML =
      hoursMod + ' : ' + minutesMod + ' : ' + secondsMod

    if (distance < 0) {
      clearInterval(x)
      document.getElementById('counter').innerHTML = 'Süre doldu!'
    }
  }
}, 1000)
/* Counter End */
